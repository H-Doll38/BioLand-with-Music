/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bioland_game2;

/**
 *
 * @author lork8
 */
public class PoliceStationScene {

    public static String getPoliceStationScene() {
        return "“As you walk down the street you see a building with multiple flags "
                + "\n outside the entrance, the sign outside says Police Station.  "
                + "\n There is a police cruiser that has drifted into the side of "
                + "\n the building.”";
    }

    public static String getPoliceStationScene2() {
        return "(You make your way to the front entrance; the doors are barricaded "
                + "\n with multiple 2x4s. When you look inside through the window, "
                + "\n you see a door leading to the inner police station. It may "
                + "\n require a keycard.)\n"
                + "\n (You walk to the crashed cruiser)";
    }

    public static String getPoliceStationScene3() {
        return "(Inside the police car, you find no weapons but do a slightly bent "
                + "\n and bloody keycard. You take the keycard.)";
    }

    public static String getPoliceStationScene4() {
        return "(You walk around the building to find an alternate way inside. "
                + "\n You find a side door with what appears to be a keypad.)";
    }

    public static String getPoliceStationScene5() {
        return "(With a light ding and green flash, the door opens.)";
    }

    public static String getPoliceStationScene6() {
        return "(You enter a long hallway with doors running abreast. Along the "
                + "\n doors are plates with what appears to be names and numbers of "
                + "\n the policemen and women of the station. A sign above you says "
                + "\n Offices.)";
    }

    public static String getPoliceStationScene7() {
        return "(You find nothing more than documents to different investigations. "
                + "\n You do manage to find a taser in one of the officer’s drawer. "
                + "\n It appears to only have one shot.)\n"
                + "\n “At the end of the hallway there is a directory of the police "
                + "\n station, right next to the offices is the jail. Past the jail "
                + "\n is the armory.”";
    }

    public static String getPoliceStationScene8() {
        return "“Five jails run alongside the wall, inside the cells are turned "
                + "\n inmates wearing orange jumpsuits. They try to reach for you "
                + "\n through the bars. There is also a broken wooden table. At "
                + "\n the end of the hallway stands a warden foaming at the mouth. "
                + "\n He wears a bulletproof vest and has a Glock in his holster.”\n"
                + "\n “He gurgles red and brown liquid out of his mouth and moves "
                + "\n at you faster than any corpse you’ve seen.  He knocks you "
                + "\n against the bars before you can take aim with the taser. "
                + "\n Some of the hands grab at you but they miss.”";
    }

    public static String getPoliceStationFirstOptionScene() {
        return "(You decide to turn and make a quick shot with the taser, the "
                + "\n wires go into nhis thigh. But to no effect, it does nothing.  "
                + "\n The warden rips your arm off, and you watch in horror as "
                + "\n he eats it before you pass out from blood loss.) "
                + "\n\n Game over...";
    }

    public static String getPoliceStationSecondOptionSceneA() {
        return "(You decide to go for the table leg. Wielding it like a bat, you "
                + "\n swing and knock him back and his eye flies out of its socket.  "
                + "\n It does not bother him but only aggravates him further.)\n"
                + "\n (You then try to taser him in the jugular, but it is "
                + "\n ineffective. You turn up the voltage which also is "
                + "\n ineffective.)\n"
                + "\n (You throw the taser to the side and try the table leg "
                + "\n once more.  You knock him back into one of the bars, where "
                + "\n the corpses hold him and take bites out of his arms and legs.  "
                + "\n While he is pinned you reach for the Glock and take it from "
                + "\n his holster. You aim at his head and pull the trigger, "
                + "\n the noise echoes through the jail and your ears begin to ring.)";
    }
     public static String getPoliceStationSecondOptionSceneB() {
        return "(The corpse goes still but is held up by the corpses eating away at "
                + "\n the warden. He has two spare magazines on his belt, but "
                + "\n you are unsure if you can get them. You depress the magazine "
                + "\n lever and pull the magazine out. There are seven bullets, "
                + "\n and the gun holds fifteen.)";
    }

    public static String getPoliceStationFirstOptionWin() {
        return "(You decide to go retrieve the magazines off the wardens belt. "
                + "\n You slowly reach for them then quickly snatch them away.)";
    }

    public static String getPoliceStationFirstOptionFail() {
        return "(You decide to go retrieve the magazines off the wardens belt. "
                + "\n You slowly reach for them. One of the corpses grabs your "
                + "\n arm, pulling it through the bars and holding you there.  "
                + "\n Afterwards you are ripped to shreds.  "
                + "\n\n Game Over...";
    }

    public static String getPoliceStationSecondOption() {
        return "(You walk away towards the armory)" ;
                
    }
    public static String getPoliceStationLastScene(){
        return "The armory is deadbolted closed and there seems to be no way of "
                + "\n getting in.  You hang your head, resting against the door "
                + "\n a moment before heading back outside.";  
    };

}
