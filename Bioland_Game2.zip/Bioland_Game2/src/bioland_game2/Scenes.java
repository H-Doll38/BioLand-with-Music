//package bioland_game2;
//
//import javafx.application.Application;
//import javafx.event.ActionEvent;
//import javafx.event.EventHandler;
//import javafx.geometry.Pos;
//import javafx.geometry.VPos;
//import javafx.scene.Group;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;
//import javafx.scene.layout.HBox;
//import javafx.scene.layout.StackPane;
//import javafx.scene.text.Font;
//import javafx.scene.text.Text;
//import javafx.stage.Stage;
//
///**
// *
// * @author lork8
// */
//public class Scenes {
//
//    Scene currentScene = null;
//
//    public Scenes(int state) {
//
//        this.createScene(state);
//
//    }
//
//    public Scene createScene(int state) {
//        Scene currentScene = null;
//        switch (state) {
//            case 1:
//                Image myImage = new Image("https://wallpaperaccess.com/full/136797.jpg");
//                ImageView imgView = new ImageView(myImage);
//                //setting the fit height and width of the image view 
//                imgView.setFitHeight(950);
//                imgView.setFitWidth(700);
//
////        Creating a Group object  
//                Group root = new Group(imgView);
//
//                Button entbtn = new Button();
//                Button quitbtn = new Button();
//                Group group = new Group();
//                Text Title = new Text();
//
//                //Buttons
//                entbtn.setText("Start");
//                entbtn.setStyle("-fx-font-size: 3em;");
//                entbtn.setPrefSize(200, 100);
//                quitbtn.setText("Quit");
//                quitbtn.setStyle("-fx-font-size: 3em;");
//                quitbtn.setPrefSize(200, 100);
//                entbtn.setDefaultButton(true);
//                HBox hbox = new HBox(entbtn, quitbtn);
////         HBox.setMargin(entbtn, new Insets(10, 10, 50, 100));
////         HBox.setMargin(quitbtn, new Insets(10,10,50,20));
//                hbox.setAlignment(Pos.BOTTOM_CENTER);
//
//                //Quit Button
//                quitbtn.setOnAction(new EventHandler<ActionEvent>() {
//
//                    @Override
//                    public void handle(ActionEvent event) {
//                        primaryStage.close();
//                    }
//                });
//                //Enter Button
//                entbtn.setOnAction(e -> primaryStage.setScene(prologue));
////            entbtn.setOnAction(new EventHandler<ActionEvent>() {
////            
////            @Override
////            public void handle(ActionEvent event) {
////              primaryStage.close();
////            }
////        });
//
//                //Title
//                Title.setText("Bioland");
//                Title.setFont(Font.font("TimesNewRoman", 200));
//                Title.setTextOrigin(VPos.BOTTOM);
//                //Group
//                StackPane pane1 = new StackPane();
//                pane1.getChildren().add(imgView);
//                pane1.getChildren().add(hbox);
//                pane1.getChildren().add(Title);
////         pane1.setLayoutX(160);
////        pane1.setLayoutY(350);
////        group.getChildren().add(imgView);
////        group.getChildren().add(hbox);
////        group.getChildren().add(Title);
////         group.getChildren().add(gPane);
//////        group.getChildren().add(imgView);
////        group.setLayoutX(160);
////        group.setLayoutY(350);
//
//                Label labelPrologue = new Label(getPrologue());
////        labelPrologue.setTranslateX(300);
////        labelPrologue.setTranslateY(300);
//
//                Button getUpButton = new Button("Get up");
//                getUpButton.setTranslateX(100);
//                getUpButton.setTranslateY(200);
//                getUpButton.setOnAction(e -> primaryStage.setScene(prologue2));
//
////        VBox box1 = new VBox();
////        box1.getChildren().add(root); 
////        box1.getChildren().add(labelPrologue);
////        box1.getChildren().add(getUpButton);
////        box1.setAlignment(Pos.CENTER);
//                StackPane pane = new StackPane();
//                pane.getChildren().add(root);
//                pane.getChildren().add(labelPrologue);
//                pane.getChildren().add(getUpButton);
////        pane.setAlignment(Pos.CENTER);
////        box1.getChildren().addAll(labelPrologue, getUpButton, imgView);
//                prologue = new Scene(pane, width, height);
//
//// this.currentScene = scene;
//                break;
//        }
//    }
//}
