package bioland_game2;
//
//import java.awt.Insets;
//import java.io.File;
//import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.nio.file.Paths;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 *
 * @author lork8
 */
public class Bioland_Game2 extends Application {
    
    int width = 800, height = 600;

    Scene prologue, prologue2, prologue3, prologue4, prologue5, prologue6, prologue7, prologue8, prologue9, prologue10;
    Scene prologue11, prologue12, prologue13, prologue14, prologue15, prologue15c;
    Scene pharmacy, pharmacy2, pharmacy3, pharmacy4, pharmacy5, pharmacy6, pharmacy7, pharmacy8, pharmacy9, pharmacy10, pharmacy11;
    Scene pharmacy12, pharmacy13, pharmacy14, pharmacy15, pharmacy16, pharmacy17;
    Scene policeStation, policeStation2, policeStation3, policeStation4, policeStation5, policeStation6, policeStation7, policeStation8;
    Scene policeStation9, policeStation10, policeStation10b, policeStation11, policeStation12, policeStation13, policeStation14;
    Scene foodMarket, foodMarket2, foodMarket3, foodMarket4, foodMarket4b, foodMarket5, foodMarket5b, foodMarket5c, foodMarket5d, foodMarket5e, foodMarket5f, foodMarket5g, foodMarket6, foodMarket7, foodMarket8, foodMarket9, foodMarket10, foodMarket11;
    Scene foodMarket12, foodMarket13, foodMarket14, foodMarket15, foodMarket16, foodMarket17;
    Scene TheEnd, TheEnd2, TheEnd3, TheEnd4, TheEnd5, TheEnd6, TheEnd7, TheEnd8, TheEnd9, TheEnd10;

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        music();
        Image myImage = new Image("https://wallpaperaccess.com/full/136797.jpg");
        ImageView imgView = new ImageView(myImage);
        //setting the fit height and width of the image view
//        imgView.setFitHeight(1000);
//        imgView.setFitWidth(600);

//        Creating a Group object
        Group rootG = new Group(imgView);

        Button entbtn = new Button();
        Button quitbtn = new Button();
        Group group = new Group();
        Text Title = new Text();

        //Buttons
        entbtn.setText("Start");
        entbtn.setStyle("-fx-font-size: 3em;");
        entbtn.setPrefSize(100, 100);
        quitbtn.setText("Quit");
        quitbtn.setStyle("-fx-font-size: 3em;");
        quitbtn.setPrefSize(100, 100);
        entbtn.setDefaultButton(true);
        HBox hbox = new HBox(entbtn, quitbtn);
//         HBox.setMargin(entbtn, new Insets(10, 10, 50, 100));
//         HBox.setMargin(quitbtn, new Insets(10,10,50,20));
        hbox.setAlignment(Pos.BOTTOM_CENTER);

        //Quit Button
        quitbtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
            }
        });
        //Enter Button
        entbtn.setOnAction(e -> primaryStage.setScene(prologue));//quick scene testing
            entbtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(prologue);
              musicStop();
              music2();
            }
        });
//        entbtn.setOnAction(e -> primaryStage.setScene(TheEnd));//quick scene testing
//            entbtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent event) {
//              primaryStage.close();
//            }
//        });

        //Title
        Title.setText("Bioland");
        Title.setStroke(Color.RED);
        Title.setFont(Font.font("TimesNewRoman", 175));
        Title.setTextOrigin(VPos.BOTTOM);
        //Group
        StackPane pane1 = new StackPane();
        pane1.getChildren().add(imgView);
        pane1.getChildren().add(hbox);
        pane1.getChildren().add(Title);
//         pane1.setLayoutX(160);
//        pane1.setLayoutY(350);
//        group.getChildren().add(imgView);
//        group.getChildren().add(hbox);
//        group.getChildren().add(Title);
//         group.getChildren().add(gPane);
////        group.getChildren().add(imgView);
//        group.setLayoutX(160);
//        group.setLayoutY(350);

        Image cabinImage = new Image("https://i.pinimg.com/originals/34/96/eb/3496ebada274edda3aaedf6a2c397cf0.png", width, height, false, false);
        ImageView imgViewCabin = new ImageView(cabinImage);
        Text labelPrologue = new Text(Strings.getPrologue());
        labelPrologue.setFont(Font.font("TimesNewRoman", 20));
        labelPrologue.setFill(Color.YELLOW);

//        labelPrologue.setTextAlignment(VPos.TOP);
//        labelPrologue.setTranslateX(300);
//        labelPrologue.setTranslateY(300);
        Group root = new Group(imgViewCabin);

        Button getUpButton = new Button("Get up");
        getUpButton.setTranslateX(-10);
        getUpButton.setTranslateY(100);

//        getUpButton.setAlignment(Pos.BOTTOM_LEFT);
        getUpButton.setOnAction(e -> primaryStage.setScene(prologue2));

//        VBox box1 = new VBox();
//        box1.getChildren().add(root);
//        box1.getChildren().add(labelPrologue);
//        box1.getChildren().add(getUpButton);
//        box1.setAlignment(Pos.CENTER);
        StackPane pane = new StackPane();
        pane.getChildren().add(root);
        pane.getChildren().add(labelPrologue);
        pane.getChildren().add(getUpButton);
//        pane.setAlignment(Pos.CENTER);
//        box1.getChildren().addAll(labelPrologue, getUpButton, imgView);
        prologue = new Scene(pane, width, height);

        Button lookButton = new Button("Look around");
        lookButton.setTranslateX(-10);
        lookButton.setTranslateY(100);
        lookButton.setOnAction(e -> primaryStage.setScene(prologue3));

        Image cabinImage2 = new Image("https://i.pinimg.com/originals/34/96/eb/3496ebada274edda3aaedf6a2c397cf0.png", width, height, false, false);
        ImageView imgViewCabin2 = new ImageView(cabinImage);
        Group root2 = new Group(imgViewCabin2);
        Text labelScene2 = new Text(Strings.getPrologue2());
        labelScene2.setFont(Font.font("TimesNewRoman", 20));
        labelScene2.setFill(Color.YELLOW);
        StackPane pane2 = new StackPane();
        pane2.getChildren().add(root2);
        pane2.getChildren().add(labelScene2);
        pane2.getChildren().add(lookButton);

//        labelScene2.setLayoutX(200);
//        labelScene2.setLayoutY(100);
//        pane2.getChildren().add(root2);
//        pane2.getChildren().add(labelScene2);
        prologue2 = new Scene(pane2, width, height);

        Button walkButton = new Button("Walk to the bathroom");
        walkButton.setTranslateX(-10);
        walkButton.setTranslateY(100);
        walkButton.setOnAction(e -> primaryStage.setScene(prologue4));

        Image cabinImage3 = new Image("https://i.pinimg.com/originals/34/96/eb/3496ebada274edda3aaedf6a2c397cf0.png", width, height, false, false);
        ImageView imgViewCabin3 = new ImageView(cabinImage);
        Group root3 = new Group(imgViewCabin3);
        Text labelScene3 = new Text(Strings.getPrologue3());
        labelScene3.setFont(Font.font("TimesNewRoman", 20));
        labelScene3.setFill(Color.YELLOW);
        StackPane pane3 = new StackPane();
        pane3.getChildren().add(root3);
        pane3.getChildren().add(labelScene3);
        pane3.getChildren().add(walkButton);

//        pane3.getChildren().addAll(labelScene3, walkButton);
        prologue3 = new Scene(pane3, width, height);

        Button mirrorButton = new Button("Look into the mirror");
        mirrorButton.setTranslateX(-10);
        mirrorButton.setTranslateY(100);
        mirrorButton.setOnAction(e -> primaryStage.setScene(prologue5));

//        Image cabinImage4 = new Image("https://i.pinimg.com/originals/34/96/eb/3496ebada274edda3aaedf6a2c397cf0.png", width, height, false, false);
        ImageView imgViewCabin4 = new ImageView(cabinImage);
        Group root4 = new Group(imgViewCabin4);
        Text labelScene4 = new Text(Strings.getPrologue4());
        labelScene4.setFont(Font.font("TimesNewRoman", 20));
        labelScene4.setFill(Color.YELLOW);
        StackPane pane4 = new StackPane();
        pane4.getChildren().add(root4);
        pane4.getChildren().add(labelScene4);
        pane4.getChildren().add(mirrorButton);
        prologue4 = new Scene(pane4, width, height);

        Button openButton = new Button("Open the cabinet");
        openButton.setTranslateX(-10);
        openButton.setTranslateY(100);
        openButton.setOnAction(e -> primaryStage.setScene(prologue6));

        ImageView imgViewCabin5 = new ImageView(cabinImage);
        Group root5 = new Group(imgViewCabin5);
        Text labelScene5 = new Text(Strings.getPrologue5());
        labelScene5.setFont(Font.font("TimesNewRoman", 20));
        labelScene5.setFill(Color.YELLOW);
        StackPane pane5 = new StackPane();
        pane5.getChildren().add(root5);
        pane5.getChildren().add(labelScene5);
        pane5.getChildren().add(openButton);
        prologue5 = new Scene(pane5, width, height);

        Button takeButton = new Button("take all");
        takeButton.setTranslateX(-10);
        takeButton.setTranslateY(100);
        takeButton.setOnAction(e -> primaryStage.setScene(prologue7));

        ImageView imgViewCabin6 = new ImageView(cabinImage);
        Group root6 = new Group(imgViewCabin6);
        Text labelScene6 = new Text(Strings.getPrologue6());
        labelScene6.setFont(Font.font("TimesNewRoman", 20));
        labelScene6.setFill(Color.YELLOW);
        StackPane pane6 = new StackPane();
        pane6.getChildren().add(root6);
        pane6.getChildren().add(labelScene6);
        pane6.getChildren().add(takeButton);
        prologue6 = new Scene(pane6, width, height);

        Button talkButton = new Button("Talk");
        talkButton.setTranslateX(-10);
        talkButton.setTranslateY(140);
        talkButton.setOnAction(e -> primaryStage.setScene(prologue8));

        ImageView imgViewCabin7 = new ImageView(cabinImage);
        Group root7 = new Group(imgViewCabin7);
        Text labelScene7 = new Text(Strings.getPrologue7());
        labelScene7.setFont(Font.font("TimesNewRoman", 20));
        labelScene7.setFill(Color.YELLOW);
        StackPane pane7 = new StackPane();
        pane7.getChildren().add(root7);
        pane7.getChildren().add(labelScene7);
        pane7.getChildren().add(talkButton);
        prologue7 = new Scene(pane7, width, height);

        Button leaveButton = new Button("Leave the bathroom");
        leaveButton.setTranslateX(-10);
        leaveButton.setTranslateY(100);
        leaveButton.setOnAction(e -> primaryStage.setScene(prologue9));

        ImageView imgViewCabin8 = new ImageView(cabinImage);
        Group root8 = new Group(imgViewCabin8);
        Text labelScene8 = new Text(Strings.getPrologue8());
        labelScene8.setFont(Font.font("TimesNewRoman", 20));
        labelScene8.setFill(Color.YELLOW);
        StackPane pane8 = new StackPane();
        pane8.getChildren().add(root8);
        pane8.getChildren().add(labelScene8);
        pane8.getChildren().add(leaveButton);
        prologue8 = new Scene(pane8, width, height);

        Button lookButton2 = new Button("Look under bed");
        lookButton2.setTranslateX(-10);
        lookButton2.setTranslateY(100);
        lookButton2.setOnAction(e -> primaryStage.setScene(prologue10));

        ImageView imgViewCabin9 = new ImageView(cabinImage);
        Group root9 = new Group(imgViewCabin9);
        Text labelScene9 = new Text(Strings.getPrologue9());
        labelScene9.setFont(Font.font("TimesNewRoman", 20));
        labelScene9.setFill(Color.YELLOW);
        StackPane pane9 = new StackPane();
        pane9.getChildren().add(root9);
        pane9.getChildren().add(labelScene9);
        pane9.getChildren().add(lookButton2);
        prologue9 = new Scene(pane9, width, height);

        Button openButton2 = new Button("Open the door");
        openButton2.setTranslateX(-10);
        openButton2.setTranslateY(100);
        openButton2.setOnAction(e -> primaryStage.setScene(prologue11));

        ImageView imgViewCabin10 = new ImageView(cabinImage);
        Group root10 = new Group(imgViewCabin10);
        Text labelScene10 = new Text(Strings.getPrologue10());
        labelScene10.setFont(Font.font("TimesNewRoman", 20));
        labelScene10.setFill(Color.YELLOW);
        StackPane pane10 = new StackPane();
        pane10.getChildren().add(root10);
        pane10.getChildren().add(labelScene10);
        pane10.getChildren().add(openButton2);
        prologue10 = new Scene(pane10, width, height);

        Button walkButton2 = new Button("Walk into hallway");
        walkButton2.setTranslateX(-10);
        walkButton2.setTranslateY(110);
        walkButton2.setOnAction(e -> primaryStage.setScene(prologue12));

        ImageView imgViewCabin11 = new ImageView(cabinImage);
        Group root11 = new Group(imgViewCabin11);
        Text labelScene11 = new Text(Strings.getPrologue11());
        labelScene11.setFont(Font.font("TimesNewRoman", 20));
        labelScene11.setFill(Color.YELLOW);
        StackPane pane11 = new StackPane();
        pane11.getChildren().add(root11);
        pane11.getChildren().add(labelScene11);
        pane11.getChildren().add(walkButton2);
        prologue11 = new Scene(pane11, width, height);

        Button enterButton = new Button("Enter the living room");
        enterButton.setTranslateX(-10);
        enterButton.setTranslateY(140);
        enterButton.setOnAction(e -> primaryStage.setScene(prologue13));

        Image cabinHallway = new Image("https://i.pinimg.com/564x/7d/0c/39/7d0c3971adc0e15b0cb0d69214320ea6.jpg", width, height, false, false);
        ImageView imgViewCabin12 = new ImageView(cabinHallway);
        Group root12 = new Group(imgViewCabin12);
        Text labelScene12 = new Text(Strings.getPrologue12());
        labelScene12.setFont(Font.font("TimesNewRoman", 20));
        labelScene12.setFill(Color.YELLOW);
        StackPane pane12 = new StackPane();
        pane12.getChildren().add(root12);
        pane12.getChildren().add(labelScene12);
        pane12.getChildren().add(enterButton);
        prologue12 = new Scene(pane12, width, height);

//fight or run in livingroom
        Button fightCreatureButton = new Button("Fight the creature");
        fightCreatureButton.setTranslateX(-10);
        fightCreatureButton.setTranslateY(140);
        fightCreatureButton.setOnAction(e -> primaryStage.setScene(prologue14));

        Button runHideButton = new Button("Run and hide");
        runHideButton.setTranslateX(-10);
        runHideButton.setTranslateY(170);
        runHideButton.setOnAction(e -> primaryStage.setScene(prologue15c));
         runHideButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(prologue15c);
              musicStop2();
              GameOver();
            }
        });

        //runanddied
        Button StartOverButton = new Button("Start Over");
        StartOverButton.setTranslateX(-10);
        StartOverButton.setTranslateY(170);
        StartOverButton.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton = new Button("Quit");
        quitButton.setTranslateX(-10);
        quitButton.setTranslateY(170);
        quitButton.setOnAction(e -> primaryStage.close());
        ImageView imgViewCabin15c = new ImageView(cabinHallway);
        Group root15c = new Group(imgViewCabin15c);
        Text labelScene15c = new Text(Strings.getRunandHide());
        labelScene15c.setFont(Font.font("TimesNewRoman", 20));
        labelScene15c.setFill(Color.YELLOW);
        StackPane pane15c = new StackPane();
        pane15c.getChildren().add(root15c);
        pane15c.getChildren().add(labelScene15c);
        pane15c.getChildren().add(StartOverButton);
        pane15c.getChildren().add(quitButton);
        prologue15c = new Scene(pane15c, width, height);

        ImageView imgViewCabin13 = new ImageView(cabinHallway);
        Group root13 = new Group(imgViewCabin13);
        Text labelScene13 = new Text(Strings.getFightInLivingRoom());
        labelScene13.setFont(Font.font("TimesNewRoman", 20));
        labelScene13.setFill(Color.YELLOW);
        StackPane pane13 = new StackPane();
        pane13.getChildren().add(root13);
        pane13.getChildren().add(labelScene13);
        pane13.getChildren().add(fightCreatureButton);
        pane13.getChildren().add(runHideButton);
        prologue13 = new Scene(pane13, width, height);

        Button continueButton2 = new Button("Continue..");
        continueButton2.setTranslateX(-10);
        continueButton2.setTranslateY(200);
        continueButton2.setOnAction(e -> primaryStage.setScene(pharmacy));

        ImageView imgViewCabin14 = new ImageView(cabinHallway);
        Group root14 = new Group(imgViewCabin14);
        Text labelScene14 = new Text(Strings.getConfuseScene());
        labelScene14.setFont(Font.font("TimesNewRoman", 20));
        labelScene14.setFill(Color.YELLOW);
        StackPane pane14 = new StackPane();
        pane14.getChildren().add(root14);
        pane14.getChildren().add(labelScene14);
        pane14.getChildren().add(continueButton2);
        prologue14 = new Scene(pane14, width, height);

///pharmacy///
        Button climbButton = new Button("Climb on the dumpster");
        climbButton.setTranslateX(-10);
        climbButton.setTranslateY(140);
        climbButton.setOnAction(e -> primaryStage.setScene(pharmacy2));

        Image pharmImage = new Image("https://cdn.jns.org/uploads/2020/06/QKjRc7m.jpg", width, height, false, false);
        ImageView imgViewPharm = new ImageView(pharmImage);
        Group root15 = new Group(imgViewPharm);
        Text labelScene15 = new Text(PharmacyStrings.getPharmScene());
        labelScene15.setFont(Font.font("TimesNewRoman", 19));
        labelScene15.setFill(Color.YELLOW);
//        labelScene15.setStroke(Color.WHITE);
        StackPane pane15 = new StackPane();
        pane15.getChildren().add(root15);
        pane15.getChildren().add(labelScene15);
        pane15.getChildren().add(climbButton);
        pharmacy = new Scene(pane15, width, height);

        Button hitButton = new Button("Hit Window");
        hitButton.setTranslateX(-10);
        hitButton.setTranslateY(140);
        hitButton.setOnAction(e -> primaryStage.setScene(pharmacy3));

        Image pharmImage2 = new Image("https://cdn.jns.org/uploads/2020/06/QKjRc7m.jpg", width, height, false, false);
        ImageView imgViewPharm2 = new ImageView(pharmImage);
        Group root16 = new Group(imgViewPharm2);
        Text labelScene16 = new Text(PharmacyStrings.getPharmScene2());
        labelScene16.setFont(Font.font("TimesNewRoman", 19));
        labelScene16.setFill(Color.YELLOW);
//        labelScene16.setStroke(Color.BLACK);
        StackPane pane16 = new StackPane();
        pane16.getChildren().add(root16);
        pane16.getChildren().add(labelScene16);
        pane16.getChildren().add(hitButton);
        pharmacy2 = new Scene(pane16, width, height);

        Button climb2Button = new Button("Climb Through");
        climb2Button.setTranslateX(-10);
        climb2Button.setTranslateY(140);
        climb2Button.setOnAction(e -> primaryStage.setScene(pharmacy4));

        ImageView imgViewPharm3 = new ImageView(pharmImage);
        Group root17 = new Group(imgViewPharm3);
        Text labelScene17 = new Text(PharmacyStrings.getPharmScene3());
        labelScene17.setFont(Font.font("TimesNewRoman", 19));
        labelScene17.setFill(Color.YELLOW);
//        labelScene17.setStroke(Color.BLACK);
        StackPane pane17 = new StackPane();
        pane17.getChildren().add(root17);
        pane17.getChildren().add(labelScene17);
        pane17.getChildren().add(climb2Button);
        pharmacy3 = new Scene(pane17, width, height);

        Button openDoorButton = new Button("Open The Door");
        openDoorButton.setTranslateX(-10);
        openDoorButton.setTranslateY(140);
        openDoorButton.setOnAction(e -> primaryStage.setScene(pharmacy5));

        ImageView imgViewPharm4 = new ImageView(pharmImage);
        Group root18 = new Group(imgViewPharm4);
        Text labelScene18 = new Text(PharmacyStrings.getPharmScene4());
        labelScene18.setFont(Font.font("TimesNewRoman", 19));
        labelScene18.setFill(Color.YELLOW);
//        labelScene18.setStroke(Color.BLACK);
        StackPane pane18 = new StackPane();
        pane18.getChildren().add(root18);
        pane18.getChildren().add(labelScene18);
        pane18.getChildren().add(openDoorButton);
        pharmacy4 = new Scene(pane18, width, height);

        //choice 1
        Button clearButton = new Button("Clear out the Area");
        clearButton.setTranslateX(-10);
        clearButton.setTranslateY(140);
        clearButton.setOnAction(e -> primaryStage.setScene(pharmacy6));
        //choice 2
        Button findButton = new Button("Find more medical supplies");
        findButton.setTranslateX(-10);
        findButton.setTranslateY(170);
        findButton.setOnAction(e -> primaryStage.setScene(pharmacy7));

        //choice 1 after scene
        ImageView imgViewPharm5 = new ImageView(pharmImage);
        Group root19 = new Group(imgViewPharm5);
        Text labelScene19 = new Text(PharmacyStrings.getPharmScene5());
        labelScene19.setFont(Font.font("TimesNewRoman", 19));
        labelScene19.setFill(Color.YELLOW);
//        labelScene19.setStroke(Color.BLACK);
        StackPane pane19 = new StackPane();
        pane19.getChildren().add(root19);
        pane19.getChildren().add(labelScene19);
        pane19.getChildren().add(clearButton);
        pane19.getChildren().add(findButton);
        pharmacy5 = new Scene(pane19, width, height);

        //choice 2 after scene
        Button bandageButton = new Button("Bandage wound with gauze");
        bandageButton.setTranslateX(-10);
        bandageButton.setTranslateY(140);
        bandageButton.setOnAction(e -> primaryStage.setScene(pharmacy8));
        ImageView imgViewPharm6 = new ImageView(pharmImage);
        Group root20 = new Group(imgViewPharm6);
        Text labelScene20 = new Text(PharmacyStrings.getPharmScene6());
        labelScene20.setFont(Font.font("TimesNewRoman", 19));
        labelScene20.setFill(Color.YELLOW);
//        labelScene20.setStroke(Color.BLACK);
        StackPane pane20 = new StackPane();
        pane20.getChildren().add(root20);
        pane20.getChildren().add(labelScene20);
        pane20.getChildren().add(bandageButton);
        pharmacy7 = new Scene(pane20, width, height);

        Button fightButton = new Button("Fight");
        fightButton.setTranslateX(-10);
        fightButton.setTranslateY(140);
        int randNum = (int) (Math.random() * 10) + 1;
        if (randNum <= 6) {
            fightButton.setOnAction(e -> primaryStage.setScene(pharmacy10));//fight to losescene
            fightButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(pharmacy10);
              musicStop2();
              GameOver();
            }
        });
        } else {
            fightButton.setOnAction(e -> primaryStage.setScene(pharmacy9));//fight to winscene
        }

        Button runButton = new Button("Run");
        runButton.setTranslateX(-10);
        runButton.setTranslateY(170);
        if (randNum <= 1) {
            runButton.setOnAction(e -> primaryStage.setScene(pharmacy11));//run and die
            runButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(pharmacy11);
              musicStop2();
              GameOver();
            }
        });
        } else {
            runButton.setOnAction(e -> primaryStage.setScene(pharmacy12));//run and survive
        }
//you die trying to run
        Button StartOverButton2 = new Button("Start Over");
        StartOverButton2.setTranslateX(-10);
        StartOverButton2.setTranslateY(170);
        StartOverButton2.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton2 = new Button("Quit");
        quitButton2.setTranslateX(-10);
        quitButton2.setTranslateY(170);
        quitButton2.setOnAction(e -> primaryStage.close());
        ImageView imgViewPharm10 = new ImageView(pharmImage);
        Group root25 = new Group(imgViewPharm10);
        Text labelScene25 = new Text(PharmacyStrings.getPharmRunDieScene());
        labelScene25.setFont(Font.font("TimesNewRoman", 19));
        labelScene25.setFill(Color.YELLOW);
//        labelScene25.setStroke(Color.BLACK);
        StackPane pane25 = new StackPane();
        pane25.getChildren().add(root25);
        pane25.getChildren().add(labelScene25);
        pane25.getChildren().add(StartOverButton2);
        pane25.getChildren().add(quitButton2);
        pharmacy11 = new Scene(pane25, width, height);

        //you live
        Button continueButton4 = new Button("Continue..");
        continueButton4.setTranslateX(-10);
        continueButton4.setTranslateY(170);
        continueButton4.setOnAction(e -> primaryStage.setScene(policeStation));//
        ImageView imgViewPharm9 = new ImageView(pharmImage);
        Group root24 = new Group(imgViewPharm9);
        Text labelScene24 = new Text(PharmacyStrings.getPharmYouLiveScene());
        labelScene24.setFont(Font.font("TimesNewRoman", 19));
        labelScene24.setFill(Color.YELLOW);
//        labelScene24.setStroke(Color.BLACK);
        StackPane pane24 = new StackPane();
        pane24.getChildren().add(root24);
        pane24.getChildren().add(labelScene24);
        pane24.getChildren().add(continueButton4);
        pharmacy12 = new Scene(pane24, width, height);

        ImageView imgViewPharm7a = new ImageView(pharmImage);
        Group root21 = new Group(imgViewPharm7a);
        Text labelScene21 = new Text(PharmacyStrings.getPharmClearOutNScene7());
        labelScene21.setFont(Font.font("TimesNewRoman", 19));
        labelScene21.setFill(Color.YELLOW);
//        labelScene21.setStroke(Color.BLACK);
        StackPane pane21 = new StackPane();
        pane21.getChildren().add(root21);
        pane21.getChildren().add(labelScene21);
        pane21.getChildren().add(fightButton);
        pane21.getChildren().add(runButton);
        pharmacy6 = new Scene(pane21, width, height);

        Button fightButtonb = new Button("Fight");
        fightButtonb.setTranslateX(-10);
        fightButtonb.setTranslateY(140);
        if (randNum <= 6) {
            fightButtonb.setOnAction(e -> primaryStage.setScene(pharmacy10));//fight to losescene
            fightButtonb.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(pharmacy10);
              musicStop2();
              GameOver();
            }
        });
        } else {
            fightButtonb.setOnAction(e -> primaryStage.setScene(pharmacy9));//fight to winscene
        }
        Button runButtonb = new Button("Run");
        runButtonb.setTranslateX(-10);
        runButtonb.setTranslateY(170);
        if (randNum <= 1) {
            runButtonb.setOnAction(e -> primaryStage.setScene(pharmacy11));//run and die
            runButtonb.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(pharmacy11);
              musicStop2();
              GameOver();
            }
        });
        } else {
            runButtonb.setOnAction(e -> primaryStage.setScene(pharmacy12));//run and survive
        }

        ImageView imgViewPharm7 = new ImageView(pharmImage);
        Group root21b = new Group(imgViewPharm7);
        Text labelScene21b = new Text(PharmacyStrings.getPharmScene7());
        labelScene21b.setFont(Font.font("TimesNewRoman", 19));
        labelScene21b.setFill(Color.YELLOW);
//        labelScene21b.setStroke(Color.BLACK);
        StackPane pane21b = new StackPane();
        pane21b.getChildren().add(root21b);
        pane21b.getChildren().add(labelScene21b);
        pane21b.getChildren().add(fightButtonb);
        pane21b.getChildren().add(runButtonb);
        pharmacy8 = new Scene(pane21b, width, height);
        //win scene after deciding to fight
        Button continueButton3 = new Button("Continue..");
        continueButton3.setTranslateX(-10);
        continueButton3.setTranslateY(140);
        continueButton3.setOnAction(e -> primaryStage.setScene(policeStation));
        ImageView imgViewPharm8 = new ImageView(pharmImage);
        Group root22 = new Group(imgViewPharm8);
        Text labelScene22 = new Text(PharmacyStrings.getPharmFightWinScene());
        labelScene22.setFont(Font.font("TimesNewRoman", 19));
        labelScene22.setFill(Color.YELLOW);
//        labelScene22.setStroke(Color.BLACK);
        StackPane pane22 = new StackPane();
        pane22.getChildren().add(root22);
        pane22.getChildren().add(labelScene22);
        pane22.getChildren().add(continueButton3);
        pharmacy9 = new Scene(pane22, width, height);

        //lose gameover scene
        Button StartOverButton3 = new Button("Start Over");
        StartOverButton3.setTranslateX(-10);
        StartOverButton3.setTranslateY(170);
        StartOverButton3.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton3 = new Button("Quit");
        quitButton3.setTranslateX(-10);
        quitButton3.setTranslateY(170);
        quitButton3.setOnAction(e -> primaryStage.close());
        ImageView imgViewPharm8a = new ImageView(pharmImage);
        Group root23 = new Group(imgViewPharm8a);
        Text labelScene23 = new Text(PharmacyStrings.getPharmFightLoseScene());
        labelScene23.setFont(Font.font("TimesNewRoman", 19));
        labelScene23.setFill(Color.YELLOW);
//        labelScene23.setStroke(Color.BLACK);
        StackPane pane23 = new StackPane();
        pane23.getChildren().add(root23);
        pane23.getChildren().add(labelScene23);
        pane23.getChildren().add(StartOverButton3);
        pane23.getChildren().add(quitButton3);
        pharmacy10 = new Scene(pane23, width, height);

        ///////////////POLICE STATION//////////////////
        ///option1 police station
        Button goButton = new Button("Go to police station");
        goButton.setTranslateX(-10);
        goButton.setTranslateY(140);
        goButton.setOnAction(e -> primaryStage.setScene(policeStation2));
        ///option 2 check police car
        Button checkButton = new Button("Check out the police car");
        checkButton.setTranslateX(-10);
        checkButton.setTranslateY(170);
        checkButton.setOnAction(e -> primaryStage.setScene(policeStation3));

        Image stationImage = new Image("https://i.redd.it/ab87raecwhi11.jpg", width, height, false, false);
        ImageView imgViewStation = new ImageView(stationImage);
        Group rootStation = new Group(imgViewStation);
        Text labelStationScene = new Text(PoliceStationScene.getPoliceStationScene());
        labelStationScene.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene.setFill(Color.YELLOW);
        StackPane paneStation = new StackPane();
        paneStation.getChildren().add(rootStation);
        paneStation.getChildren().add(labelStationScene);
        paneStation.getChildren().add(goButton);
        paneStation.getChildren().add(checkButton);
        policeStation = new Scene(paneStation, width, height);

        Button investigateButton = new Button("Investigate");
        investigateButton.setTranslateX(-10);
        investigateButton.setTranslateY(140);
        investigateButton.setOnAction(e -> primaryStage.setScene(policeStation3));

        ImageView imgViewStation2 = new ImageView(stationImage);
        Group rootStation2 = new Group(imgViewStation2);
        Text labelStationScene2 = new Text(PoliceStationScene.getPoliceStationScene2());
        labelStationScene2.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene2.setFill(Color.YELLOW);
        StackPane paneStation2 = new StackPane();
        paneStation2.getChildren().add(rootStation2);
        paneStation2.getChildren().add(labelStationScene2);
        paneStation2.getChildren().add(investigateButton);
        policeStation2 = new Scene(paneStation2, width, height);

        Button circleButton = new Button("Circle the building");
        circleButton.setTranslateX(-10);
        circleButton.setTranslateY(140);
        circleButton.setOnAction(e -> primaryStage.setScene(policeStation4));

        ImageView imgViewStation3 = new ImageView(stationImage);
        Group rootStation3 = new Group(imgViewStation3);
        Text labelStationScene3 = new Text(PoliceStationScene.getPoliceStationScene3());
        labelStationScene3.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene3.setFill(Color.YELLOW);
        StackPane paneStation3 = new StackPane();
        paneStation3.getChildren().add(rootStation3);
        paneStation3.getChildren().add(labelStationScene3);
        paneStation3.getChildren().add(circleButton);
        policeStation3 = new Scene(paneStation3, width, height);

        Button tryButton = new Button("Try the keycard");
        tryButton.setTranslateX(-10);
        tryButton.setTranslateY(140);
        tryButton.setOnAction(e -> primaryStage.setScene(policeStation5));

        ImageView imgViewStation4 = new ImageView(stationImage);
        Group rootStation4 = new Group(imgViewStation4);
        Text labelStationScene4 = new Text(PoliceStationScene.getPoliceStationScene4());
        labelStationScene4.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene4.setFill(Color.YELLOW);
        StackPane paneStation4 = new StackPane();
        paneStation4.getChildren().add(rootStation4);
        paneStation4.getChildren().add(labelStationScene4);
        paneStation4.getChildren().add(tryButton);
        policeStation4 = new Scene(paneStation4, width, height);

        Button enterBuildingButton = new Button("Enter the buildiing");
        enterBuildingButton.setTranslateX(-10);
        enterBuildingButton.setTranslateY(140);
        enterBuildingButton.setOnAction(e -> primaryStage.setScene(policeStation6));

        ImageView imgViewStation5 = new ImageView(stationImage);
        Group rootStation5 = new Group(imgViewStation5);
        Text labelStationScene5 = new Text(PoliceStationScene.getPoliceStationScene5());
        labelStationScene5.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene5.setFill(Color.YELLOW);
        StackPane paneStation5 = new StackPane();
        paneStation5.getChildren().add(rootStation5);
        paneStation5.getChildren().add(labelStationScene5);
        paneStation5.getChildren().add(enterBuildingButton);
        policeStation5 = new Scene(paneStation5, width, height);

        Button searchButton = new Button("Quick search the offices");
        searchButton.setTranslateX(-10);
        searchButton.setTranslateY(140);
        searchButton.setOnAction(e -> primaryStage.setScene(policeStation7));

        ImageView imgViewStation6 = new ImageView(stationImage);
        Group rootStation6 = new Group(imgViewStation6);
        Text labelStationScene6 = new Text(PoliceStationScene.getPoliceStationScene6());
        labelStationScene6.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene6.setFill(Color.YELLOW);
        StackPane paneStation6 = new StackPane();
        paneStation6.getChildren().add(rootStation6);
        paneStation6.getChildren().add(labelStationScene6);
        paneStation6.getChildren().add(searchButton);
        policeStation6 = new Scene(paneStation6, width, height);

        Button enterJailButton = new Button("Enter the jail");
        enterJailButton.setTranslateX(-10);
        enterJailButton.setTranslateY(140);
        enterJailButton.setOnAction(e -> primaryStage.setScene(policeStation8));

        ImageView imgViewStation7 = new ImageView(stationImage);
        Group rootStation7 = new Group(imgViewStation7);
        Text labelStationScene7 = new Text(PoliceStationScene.getPoliceStationScene7());
        labelStationScene7.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene7.setFill(Color.YELLOW);
        StackPane paneStation7 = new StackPane();
        paneStation7.getChildren().add(rootStation7);
        paneStation7.getChildren().add(labelStationScene7);
        paneStation7.getChildren().add(enterJailButton);
        policeStation7 = new Scene(paneStation7, width, height);

        //option 1: tase close range
        Button taserButton = new Button("Try the taser at close range");
        taserButton.setTranslateX(-10);
        taserButton.setTranslateY(140);
        taserButton.setOnAction(e -> primaryStage.setScene(policeStation9));
        taserButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(policeStation9);
              musicStop2();
              GameOver();
            }
        });

        //option 2: try for table leg
        Button tableButton = new Button("Try for the table leg");
        tableButton.setTranslateX(-10);
        tableButton.setTranslateY(170);
        tableButton.setOnAction(e -> primaryStage.setScene(policeStation10));
//
        ImageView imgViewStation8 = new ImageView(stationImage);
        Group rootStation8 = new Group(imgViewStation8);
        Text labelStationScene8 = new Text(PoliceStationScene.getPoliceStationScene8());
        labelStationScene8.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene8.setFill(Color.YELLOW);
        StackPane paneStation8 = new StackPane();
        paneStation8.getChildren().add(rootStation8);
        paneStation8.getChildren().add(labelStationScene8);
        paneStation8.getChildren().add(taserButton);
        paneStation8.getChildren().add(tableButton);
        policeStation8 = new Scene(paneStation8, width, height);

        //tase to gameover scene
        Button StartOverButton4 = new Button("Start Over");
        StartOverButton4.setTranslateX(-10);
        StartOverButton4.setTranslateY(140);
        StartOverButton4.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton4 = new Button("Quit");
        quitButton4.setTranslateX(-10);
        quitButton4.setTranslateY(170);
        quitButton4.setOnAction(e -> primaryStage.close());
        ImageView imgViewStation0 = new ImageView(stationImage);
        Group rootStation0 = new Group(imgViewStation0);
        Text labelStationScene0 = new Text(PoliceStationScene.getPoliceStationFirstOptionScene());
        labelStationScene0.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene0.setFill(Color.YELLOW);
        StackPane paneStation0 = new StackPane();
        paneStation0.getChildren().add(rootStation0);
        paneStation0.getChildren().add(labelStationScene0);
        paneStation0.getChildren().add(StartOverButton4);
        paneStation0.getChildren().add(quitButton4);
        policeStation9 = new Scene(paneStation0, width, height);

        //option1: get the magz off warden(50% of dying)
        Button getMagButton = new Button("Get the magzines off the warden");
        getMagButton.setTranslateX(-10);
        getMagButton.setTranslateY(140);
        int randNumMag = (int) (Math.random() * 2) + 1;
        if (randNumMag < 2) {
            getMagButton.setOnAction(e -> primaryStage.setScene(policeStation12));//fight to losescene
            getMagButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(policeStation12);
              musicStop2();
              GameOver();
            }
        });
        } else {
            getMagButton.setOnAction(e -> primaryStage.setScene(policeStation11));//fight to winscene
        }
//        getMagButton.setOnAction(e -> primaryStage.setScene(policeStation11));

        //option2: leave it
        Button continButton = new Button("Continue...");
        continButton.setTranslateX(-10);
        continButton.setTranslateY(190);
        continButton.setOnAction(e -> primaryStage.setScene(policeStation10b));

        ImageView imgViewStation9a = new ImageView(stationImage);
        Group rootStation9a = new Group(imgViewStation9a);
        Text labelStationScene9a = new Text(PoliceStationScene.getPoliceStationSecondOptionSceneA());
        labelStationScene9a.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene9a.setFill(Color.YELLOW);
        StackPane paneStation9a = new StackPane();
        paneStation9a.getChildren().add(rootStation9a);
        paneStation9a.getChildren().add(labelStationScene9a);
        paneStation9a.getChildren().add(continButton);
        policeStation10 = new Scene(paneStation9a, width, height);

        Button leaveItButton = new Button("Leave it");
        leaveItButton.setTranslateX(-10);
        leaveItButton.setTranslateY(170);
        leaveItButton.setOnAction(e -> primaryStage.setScene(policeStation14));

        ImageView imgViewStation9 = new ImageView(stationImage);
        Group rootStation9 = new Group(imgViewStation9);
        Text labelStationScene9 = new Text(PoliceStationScene.getPoliceStationSecondOptionSceneB());
        labelStationScene9.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene9.setFill(Color.YELLOW);
        StackPane paneStation9 = new StackPane();
        paneStation9.getChildren().add(rootStation9);
        paneStation9.getChildren().add(labelStationScene9);
        paneStation9.getChildren().add(getMagButton);
        paneStation9.getChildren().add(leaveItButton);
        policeStation10b = new Scene(paneStation9, width, height);

        //option1 winning scene
        Button continueButton5 = new Button("Continue...");
        continueButton5.setTranslateX(-10);
        continueButton5.setTranslateY(140);
        continueButton5.setOnAction(e -> primaryStage.setScene(policeStation13));

        //option1 win
        ImageView imgViewStation10 = new ImageView(stationImage);
        Group rootStation10 = new Group(imgViewStation10);
        Text labelStationScene10 = new Text(PoliceStationScene.getPoliceStationFirstOptionWin());
        labelStationScene10.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene10.setFill(Color.YELLOW);
        StackPane paneStation10 = new StackPane();
        paneStation10.getChildren().add(rootStation10);
        paneStation10.getChildren().add(labelStationScene10);
        paneStation10.getChildren().add(continueButton5);
        policeStation11 = new Scene(paneStation10, width, height);

        //option2 lose gameover
        Button StartOverButton5 = new Button("Start Over");
        StartOverButton5.setTranslateX(-10);
        StartOverButton5.setTranslateY(140);
        StartOverButton5.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton5 = new Button("Quit");
        quitButton5.setTranslateX(-10);
        quitButton5.setTranslateY(170);
        quitButton5.setOnAction(e -> primaryStage.close());
        ImageView imgViewStation11 = new ImageView(stationImage);
        Group rootStation11 = new Group(imgViewStation11);
        Text labelStationScene11 = new Text(PoliceStationScene.getPoliceStationFirstOptionFail());
        labelStationScene11.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene11.setFill(Color.YELLOW);
        StackPane paneStation11 = new StackPane();
        paneStation11.getChildren().add(rootStation11);
        paneStation11.getChildren().add(labelStationScene11);
        paneStation11.getChildren().add(StartOverButton5);
        paneStation11.getChildren().add(quitButton5);
        policeStation12 = new Scene(paneStation11, width, height);

        //option2 leave it 
        Button continueButton7 = new Button("Continue...");
        continueButton7.setTranslateX(-10);
        continueButton7.setTranslateY(140);
        continueButton7.setOnAction(e -> primaryStage.setScene(policeStation13));

        ImageView imgViewStation13 = new ImageView(stationImage);
        Group rootStation13 = new Group(imgViewStation13);
        Text labelStationScene13 = new Text(PoliceStationScene.getPoliceStationSecondOption());
        labelStationScene13.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene13.setFill(Color.YELLOW);
        StackPane paneStation13 = new StackPane();
        paneStation13.getChildren().add(rootStation13);
        paneStation13.getChildren().add(labelStationScene13);
        paneStation13.getChildren().add(continueButton7);
        policeStation14 = new Scene(paneStation13, width, height);

        //police last scene
        Button continueButton6 = new Button("Continue...");
        continueButton6.setTranslateX(-10);
        continueButton6.setTranslateY(140);
        continueButton6.setOnAction(e -> primaryStage.setScene(foodMarket));

        ImageView imgViewStation12 = new ImageView(stationImage);
        Group rootStation12 = new Group(imgViewStation12);
        Text labelStationScene12 = new Text(PoliceStationScene.getPoliceStationLastScene());
        labelStationScene12.setFont(Font.font("TimesNewRoman", 19));
        labelStationScene12.setFill(Color.YELLOW);
        StackPane paneStation12 = new StackPane();
        paneStation12.getChildren().add(rootStation12);
        paneStation12.getChildren().add(labelStationScene12);
        paneStation12.getChildren().add(continueButton6);
        policeStation13 = new Scene(paneStation12, width, height);

        /////////Food Market///////////////
        Button enterBayButton = new Button("Enter the loading bay");
        enterBayButton.setTranslateX(-10);
        enterBayButton.setTranslateY(140);
        enterBayButton.setOnAction(e -> primaryStage.setScene(foodMarket2));

        Image marketImage = new Image("https://i.pinimg.com/originals/03/d1/9a/03d19a478095917dff48cd97995332a9.jpg", width, height, false, false);
        ImageView imgViewMarket = new ImageView(marketImage);
        Group rootMarket = new Group(imgViewMarket);
        Text labelMarketScene = new Text(FoodMarketScene.getFoodMarketScene());
        labelMarketScene.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene.setFill(Color.YELLOW);
//        labelMarketScene.setStroke(Color.RED);
        StackPane paneMarket = new StackPane();
        paneMarket.getChildren().add(rootMarket);
        paneMarket.getChildren().add(labelMarketScene);
        paneMarket.getChildren().add(enterBayButton);
        foodMarket = new Scene(paneMarket, width, height);

        Button enterStoreButton = new Button("Enter store");
        enterStoreButton.setTranslateX(-10);
        enterStoreButton.setTranslateY(140);
        enterStoreButton.setOnAction(e -> primaryStage.setScene(foodMarket3));

        ImageView imgViewMarket2 = new ImageView(marketImage);
        Group rootMarket2 = new Group(imgViewMarket2);
        Text labelMarketScene2 = new Text(FoodMarketScene.getFoodMarketScene2());
        labelMarketScene2.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene2.setFill(Color.YELLOW);
//        labelMarketScene2.setStroke(Color.BLACK);
        StackPane paneMarket2 = new StackPane();
        paneMarket2.getChildren().add(rootMarket2);
        paneMarket2.getChildren().add(labelMarketScene2);
        paneMarket2.getChildren().add(enterStoreButton);
        foodMarket2 = new Scene(paneMarket2, width, height);

        //option1 telling truth
        Button introButton = new Button("My name's Hank, I'm just here looking for food.");
        introButton.setTranslateX(-10);
        introButton.setTranslateY(140);
        introButton.setOnAction(e -> primaryStage.setScene(foodMarket4));
        //option2 telling lies
        Button introButton2 = new Button("My name’s Nunya, Nuyah fuckin business.");
        introButton2.setTranslateX(-10);
        introButton2.setTranslateY(170);
        introButton2.setOnAction(e -> primaryStage.setScene(foodMarket4b));
        introButton2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
              primaryStage.setScene(foodMarket4b);
              musicStop2();
              GameOver();
            }
        });

        ImageView imgViewMarket3 = new ImageView(marketImage);
        Group rootMarket3 = new Group(imgViewMarket3);
        Text labelMarketScene3 = new Text(FoodMarketScene.getFoodMarketScene3());
        labelMarketScene3.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene3.setFill(Color.YELLOW);
////        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneMarket3 = new StackPane();
        paneMarket3.getChildren().add(rootMarket3);
        paneMarket3.getChildren().add(labelMarketScene3);
        paneMarket3.getChildren().add(introButton);
        paneMarket3.getChildren().add(introButton2);
        foodMarket3 = new Scene(paneMarket3, width, height);

        //option2 lies and dies
        Button StartOverButton6 = new Button("Start Over");
        StartOverButton6.setTranslateX(-10);
        StartOverButton6.setTranslateY(140);
        StartOverButton6.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton6 = new Button("Quit");
        quitButton6.setTranslateX(-10);
        quitButton6.setTranslateY(170);
        quitButton6.setOnAction(e -> primaryStage.close());
        ImageView imgViewMarket4b = new ImageView(marketImage);
        Group rootMarket4b = new Group(imgViewMarket4b);
        Text labelMarketScene4b = new Text(FoodMarketScene.getFoodMarketChoice2());
        labelMarketScene4b.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene4b.setFill(Color.YELLOW);
//        labelMarketScene4b.setStroke(Color.BLACK);
        StackPane paneMarket4b = new StackPane();
        paneMarket4b.getChildren().add(rootMarket4b);
        paneMarket4b.getChildren().add(labelMarketScene4b);
        paneMarket4b.getChildren().add(StartOverButton6);
        paneMarket4b.getChildren().add(quitButton6);
        foodMarket4b = new Scene(paneMarket4b, width, height);

        //option1 scene
        Button WalkAislesButton = new Button("Walk the aisles");
        WalkAislesButton.setTranslateX(-10);
        WalkAislesButton.setTranslateY(140);
        WalkAislesButton.setOnAction(e -> primaryStage.setScene(foodMarket5));
        //option2 scene
        Button askButton = new Button("Ask questions");
        askButton.setTranslateX(-10);
        askButton.setTranslateY(170);
        askButton.setOnAction(e -> primaryStage.setScene(foodMarket5b));
        ////ask questons scene
        ///seen sarah?
        Button seenSarahButton = new Button("Have you seen a little girl, her name’s Lily? "
                + "\nShe’s eight, blonde hair, brown eyes.  "
                + "\nShe should be with my wife Sarah.");
        seenSarahButton.setTranslateX(-10);
        seenSarahButton.setTranslateY(140);
        seenSarahButton.setOnAction(e -> primaryStage.setScene(foodMarket5c));
        ImageView imgViewMarket5b = new ImageView(marketImage);
        Group rootMarket5b = new Group(imgViewMarket5b);
        Text labelMarketScene5b = new Text(FoodMarketScene.getFoodMarketAskQuestion());
        labelMarketScene5b.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene5b.setFill(Color.YELLOW);
//        labelMarketScene5.setStroke(Color.BLACK);
        StackPane paneMarket5b = new StackPane();
        paneMarket5b.getChildren().add(rootMarket5b);
        paneMarket5b.getChildren().add(labelMarketScene5b);
        paneMarket5b.getChildren().add(seenSarahButton);
        foodMarket5b = new Scene(paneMarket5b, width, height);
        ///why so dark?
        Button whyDarkButton = new Button("Why is it so dark in here?");
        whyDarkButton.setTranslateX(-10);
        whyDarkButton.setTranslateY(140);
        whyDarkButton.setOnAction(e -> primaryStage.setScene(foodMarket5d));
        ImageView imgViewMarket5c = new ImageView(marketImage);
        Group rootMarket5c = new Group(imgViewMarket5c);
        Text labelMarketScene5c = new Text(FoodMarketScene.getFoodMarketRespond());
        labelMarketScene5c.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene5c.setFill(Color.YELLOW);
//        labelMarketScene5.setStroke(Color.BLACK);
        StackPane paneMarket5c = new StackPane();
        paneMarket5c.getChildren().add(rootMarket5c);
        paneMarket5c.getChildren().add(labelMarketScene5c);
        paneMarket5c.getChildren().add(whyDarkButton);
        foodMarket5c = new Scene(paneMarket5c, width, height);
        ///What smell??
        Button smellButton = new Button("What's that smell?");
        smellButton.setTranslateX(-10);
        smellButton.setTranslateY(140);
        smellButton.setOnAction(e -> primaryStage.setScene(foodMarket5e));
        ImageView imgViewMarket5d = new ImageView(marketImage);
        Group rootMarket5d = new Group(imgViewMarket5d);
        Text labelMarketScene5d = new Text(FoodMarketScene.getFoodMarketRespond2());
        labelMarketScene5d.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene5d.setFill(Color.YELLOW);
//        labelMarketScene5.setStroke(Color.BLACK);
        StackPane paneMarket5d = new StackPane();
        paneMarket5d.getChildren().add(rootMarket5d);
        paneMarket5d.getChildren().add(labelMarketScene5d);
        paneMarket5d.getChildren().add(smellButton);
        foodMarket5d = new Scene(paneMarket5d, width, height);
        ///last response
        Button WalkAislesButton2 = new Button("Walk the aisles");
        WalkAislesButton2.setTranslateX(-10);
        WalkAislesButton2.setTranslateY(140);
        WalkAislesButton2.setOnAction(e -> primaryStage.setScene(foodMarket5f));
        ImageView imgViewMarket5e = new ImageView(marketImage);
        Group rootMarket5e = new Group(imgViewMarket5e);
        Text labelMarketScene5e = new Text(FoodMarketScene.getFoodMarketRespond3());
        labelMarketScene5e.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene5e.setFill(Color.YELLOW);
//        labelMarketScene5.setStroke(Color.BLACK);
        StackPane paneMarket5e = new StackPane();
        paneMarket5e.getChildren().add(rootMarket5e);
        paneMarket5e.getChildren().add(labelMarketScene5e);
        paneMarket5e.getChildren().add(WalkAislesButton2);
        foodMarket5e = new Scene(paneMarket5e, width, height);
        //back to walking the aisle
        Button continueButton10 = new Button("Continue...");
        continueButton10.setTranslateX(-10);
        continueButton10.setTranslateY(140);
        continueButton10.setOnAction(e -> primaryStage.setScene(foodMarket6));
        ImageView imgViewMarket5f = new ImageView(marketImage);
        Group rootMarket5f = new Group(imgViewMarket5f);
        Text labelMarketScene5f = new Text(FoodMarketScene.getFoodMarketChooseWalkAisles2());
        labelMarketScene5f.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene5f.setFill(Color.YELLOW);
        StackPane paneMarket5f = new StackPane();
        paneMarket5f.getChildren().add(rootMarket5f);
        paneMarket5f.getChildren().add(labelMarketScene5f);
        paneMarket5f.getChildren().add(continueButton10);
        foodMarket5f = new Scene(paneMarket5f, width, height);

        //option 1 looking for food down the aisle
        Button continueButton8 = new Button("Continue...");
        continueButton8.setTranslateX(-10);
        continueButton8.setTranslateY(170);
        continueButton8.setOnAction(e -> primaryStage.setScene(foodMarket6));//go to getFoodMarketScene4()
        //^^^^^^^^^^^^^^^^^^^^^^^needs to be worked on
        ImageView imgViewMarket5 = new ImageView(marketImage);
        Group rootMarket5 = new Group(imgViewMarket5);
        Text labelMarketScene5 = new Text(FoodMarketScene.getFoodMarketChooseWalkAisles());
        labelMarketScene5.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene5.setFill(Color.YELLOW);
//        labelMarketScene5.setStroke(Color.BLACK);
        StackPane paneMarket5 = new StackPane();
        paneMarket5.getChildren().add(rootMarket5);
        paneMarket5.getChildren().add(labelMarketScene5);
        paneMarket5.getChildren().add(continueButton8);
        foodMarket5 = new Scene(paneMarket5, width, height);

        Button continueButton9 = new Button("Continue...");
        continueButton9.setTranslateX(-10);
        continueButton9.setTranslateY(180);
        continueButton9.setOnAction(e -> primaryStage.setScene(foodMarket7));
        ImageView imgViewMarket9 = new ImageView(marketImage);
        Group rootMarket9 = new Group(imgViewMarket9);
        Text labelMarketScene9 = new Text(FoodMarketScene.getFoodMarketScene4());
        labelMarketScene9.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene9.setFill(Color.YELLOW);
//        labelMarketScene9.setStroke(Color.BLACK);
        StackPane paneMarket9 = new StackPane();
        paneMarket9.getChildren().add(rootMarket9);
        paneMarket9.getChildren().add(labelMarketScene9);
        paneMarket9.getChildren().add(continueButton9);
        foodMarket6 = new Scene(paneMarket9, width, height);

        Button revengeButton = new Button("Get revenge");
        revengeButton.setTranslateX(-10);
        revengeButton.setTranslateY(140);
        revengeButton.setOnAction(e -> primaryStage.setScene(foodMarket8));
        Button corpsesButton = new Button("Let the corpses finish them off");
        corpsesButton.setTranslateX(-10);
        corpsesButton.setTranslateY(170);
        corpsesButton.setOnAction(e -> primaryStage.setScene(foodMarket9));

        ImageView imgViewMarket10 = new ImageView(marketImage);
        Group rootMarket10 = new Group(imgViewMarket10);
        Text labelMarketScene10 = new Text(FoodMarketScene.getFoodMarketScene5());
        labelMarketScene10.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene10.setFill(Color.YELLOW);
//        labelMarketScene9.setStroke(Color.BLACK);
        StackPane paneMarket10 = new StackPane();
        paneMarket10.getChildren().add(rootMarket10);
        paneMarket10.getChildren().add(labelMarketScene10);
        paneMarket10.getChildren().add(revengeButton);
        paneMarket10.getChildren().add(corpsesButton);
        foodMarket7 = new Scene(paneMarket10, width, height);

        ImageView imgViewMarket4 = new ImageView(marketImage);
        Group rootMarket4 = new Group(imgViewMarket4);
        Text labelMarketScene4 = new Text(FoodMarketScene.getFoodMarketChoice1());
        labelMarketScene4.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene4.setFill(Color.YELLOW);
//        labelMarketScene4.setStroke(Color.BLACK);
        StackPane paneMarket4 = new StackPane();
        paneMarket4.getChildren().add(rootMarket4);
        paneMarket4.getChildren().add(labelMarketScene4);
        paneMarket4.getChildren().add(WalkAislesButton);
        paneMarket4.getChildren().add(askButton);
        foodMarket4 = new Scene(paneMarket4, width, height);

        //ask question scene
        Button askButton2 = new Button("Have you seen a little girl, her name’s Lily? "
                + "\nShe’s eight, blonde hair, brown eyes.  "
                + "\nShe should be with my wife Sarah.");
        askButton2.setTranslateX(-10);
        askButton2.setTranslateY(140);
        askButton2.setOnAction(e -> primaryStage.setScene(foodMarket6));//go to getFoodMarketScene4()

        //////////get revenge
        Button continueButton11 = new Button("Continue...");
        continueButton11.setTranslateX(-10);
        continueButton11.setTranslateY(140);
        continueButton11.setOnAction(e -> primaryStage.setScene(TheEnd));
        ImageView imgViewMarket11 = new ImageView(marketImage);
        Group rootMarket11 = new Group(imgViewMarket11);
        Text labelMarketScene11 = new Text(FoodMarketScene.getFoodMarketGetRevengeChoice1());
        labelMarketScene11.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene11.setFill(Color.YELLOW);
//        labelMarketScene9.setStroke(Color.BLACK);
        StackPane paneMarket11 = new StackPane();
        paneMarket11.getChildren().add(rootMarket11);
        paneMarket11.getChildren().add(labelMarketScene11);
        paneMarket11.getChildren().add(continueButton11);
        foodMarket8 = new Scene(paneMarket11, width, height);
        /////let corpses finish
        Button continueButton12 = new Button("Continue...");
        continueButton12.setTranslateX(-10);
        continueButton12.setTranslateY(140);
        continueButton12.setOnAction(e -> primaryStage.setScene(TheEnd));
        ImageView imgViewMarket12 = new ImageView(marketImage);
        Group rootMarket12 = new Group(imgViewMarket12);
        Text labelMarketScene12 = new Text(FoodMarketScene.getFoodMarketGetRevengeChoice2());
        labelMarketScene12.setFont(Font.font("TimesNewRoman", 19));
        labelMarketScene12.setFill(Color.YELLOW);
//        labelMarketScene9.setStroke(Color.BLACK);
        StackPane paneMarket12 = new StackPane();
        paneMarket12.getChildren().add(rootMarket12);
        paneMarket12.getChildren().add(labelMarketScene12);
        paneMarket12.getChildren().add(continueButton12);
        foodMarket9 = new Scene(paneMarket12, width, height);

//////TheEnd??????????////
        Button continueButton13 = new Button("Continue...");
        continueButton13.setTranslateX(-10);
        continueButton13.setTranslateY(140);
        continueButton13.setOnAction(e -> primaryStage.setScene(TheEnd2));

        Image endImage = new Image("http://wiki.urbandead.com/images/0/03/Fire_station_HRFD.jpg", width, height, false, false);
        ImageView imgViewEnd = new ImageView(endImage);
        Group rootEnd = new Group(imgViewEnd);
        Text labelEnd = new Text(TheEndScene.getTheEndScene());
        labelEnd.setFont(Font.font("TimesNewRoman", 19));
        labelEnd.setFill(Color.YELLOW);
//        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd = new StackPane();
        paneEnd.getChildren().add(rootEnd);
        paneEnd.getChildren().add(labelEnd);
        paneEnd.getChildren().add(continueButton13);
        TheEnd = new Scene(paneEnd, width, height);

        //respnse 1
        Button respondbutton = new Button("“That’s not important, how many of you are there?” ");
        respondbutton.setTranslateX(-10);
        respondbutton.setTranslateY(140);
        respondbutton.setOnAction(e -> primaryStage.setScene(TheEnd3));
        ///response2
        Button respondbutton2 = new Button("“My name’s Nunyah, Nunyah fuckin business.”");
        respondbutton2.setTranslateX(-10);
        respondbutton2.setTranslateY(170);
        respondbutton2.setOnAction(e -> primaryStage.setScene(TheEnd3));

//        Image endImage2 = new Image("http://wiki.urbandead.com/images/0/03/Fire_station_HRFD.jpg", width, height, false, false);
        ImageView imgViewEnd2 = new ImageView(endImage);
        Group rootEnd2 = new Group(imgViewEnd2);
        Text labelEnd2 = new Text(TheEndScene.getTheEndScene2());
        labelEnd2.setFont(Font.font("TimesNewRoman", 19));
        labelEnd2.setFill(Color.YELLOW);
//        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd2 = new StackPane();
        paneEnd2.getChildren().add(rootEnd2);
        paneEnd2.getChildren().add(labelEnd2);
        paneEnd2.getChildren().add(respondbutton);
        paneEnd2.getChildren().add(respondbutton2);
        TheEnd2 = new Scene(paneEnd2, width, height);

        Button whereLillybutton = new Button("“Where’s Lily?”");
        whereLillybutton.setTranslateX(-10);
        whereLillybutton.setTranslateY(140);
        whereLillybutton.setOnAction(e -> primaryStage.setScene(TheEnd4));

        ImageView imgViewEnd3 = new ImageView(endImage);
        Group rootEnd3 = new Group(imgViewEnd3);
        Text labelEnd3 = new Text(TheEndScene.getTheEndScene3());
        labelEnd3.setFont(Font.font("TimesNewRoman", 19));
        labelEnd3.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd3 = new StackPane();
        paneEnd3.getChildren().add(rootEnd3);
        paneEnd3.getChildren().add(labelEnd3);
        paneEnd3.getChildren().add(whereLillybutton);
        TheEnd3 = new Scene(paneEnd3, width, height);

        Button continueButton14 = new Button("Continue...");
        continueButton14.setTranslateX(-10);
        continueButton14.setTranslateY(140);
        continueButton14.setOnAction(e -> primaryStage.setScene(TheEnd5));

        ImageView imgViewEnd4 = new ImageView(endImage);
        Group rootEnd4 = new Group(imgViewEnd4);
        Text labelEnd4 = new Text(TheEndScene.getTheEndScene4());
        labelEnd4.setFont(Font.font("TimesNewRoman", 19));
        labelEnd4.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd4 = new StackPane();
        paneEnd4.getChildren().add(rootEnd4);
        paneEnd4.getChildren().add(labelEnd4);
        paneEnd4.getChildren().add(continueButton14);
        TheEnd4 = new Scene(paneEnd4, width, height);

        Button continueButton15 = new Button("Continue...");
        continueButton15.setTranslateX(-10);
        continueButton15.setTranslateY(150);
        continueButton15.setOnAction(e -> primaryStage.setScene(TheEnd6));

        Image endImage5 = new Image("http://wiki.urbandead.com/images/0/03/Fire_station_HRFD.jpg", width, height, false, false);
        ImageView imgViewEnd5 = new ImageView(endImage);
        Group rootEnd5 = new Group(imgViewEnd5);
        Text labelEnd5 = new Text(TheEndScene.getTheEndScene5());
        labelEnd5.setFont(Font.font("TimesNewRoman", 19));
        labelEnd5.setFill(Color.YELLOW);
        StackPane paneEnd5 = new StackPane();
        paneEnd5.getChildren().add(rootEnd5);
        paneEnd5.getChildren().add(labelEnd5);
        paneEnd5.getChildren().add(continueButton15);
        TheEnd5 = new Scene(paneEnd5, width, height);

        Button runWifeButton = new Button("Run with wife to the boatyard and escape");
        runWifeButton.setTranslateX(-10);
        runWifeButton.setTranslateY(140);
        runWifeButton.setOnAction(e -> primaryStage.setScene(TheEnd7));//ending1

        Button runAloneButton = new Button("Run to the lighthouse by yourself");
        runAloneButton.setTranslateX(-10);
        runAloneButton.setTranslateY(170);
        runAloneButton.setOnAction(e -> primaryStage.setScene(TheEnd8));//ending 2

        Image endImage6 = new Image("https://s3.envato.com/files/234669108/pw.jpg", width, height, false, false);
        ImageView imgViewEnd6 = new ImageView(endImage6);
        Group rootEnd6 = new Group(imgViewEnd6);
        Text labelEnd6 = new Text(TheEndScene.getTheEndScene6());
        labelEnd6.setFont(Font.font("TimesNewRoman", 19));
        labelEnd6.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd6 = new StackPane();
        paneEnd6.getChildren().add(rootEnd6);
        paneEnd6.getChildren().add(labelEnd6);
        paneEnd6.getChildren().add(runWifeButton);
        paneEnd6.getChildren().add(runAloneButton);
        TheEnd6 = new Scene(paneEnd6, width, height);

//        ending1
        Button StartOverButton7 = new Button("Start Over");
        StartOverButton7.setTranslateX(-10);
        StartOverButton7.setTranslateY(200);
        StartOverButton7.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton7 = new Button("Quit");
        quitButton7.setTranslateX(-10);
        quitButton7.setTranslateY(230);
        quitButton7.setOnAction(e -> primaryStage.close());

        Image endImage7 = new Image("http://www.actua.co.uk/content/images/2018/04/IMG_8175-1.jpg", width, height, false, false);
        ImageView imgViewEnd7 = new ImageView(endImage7);
        Group rootEnd7 = new Group(imgViewEnd7);
        Text labelEnd7 = new Text(TheEndScene.getTheEndScenePart1());
        labelEnd7.setFont(Font.font("TimesNewRoman", 19));
        labelEnd7.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd7 = new StackPane();
        paneEnd7.getChildren().add(rootEnd7);
        paneEnd7.getChildren().add(labelEnd7);
        paneEnd7.getChildren().add(quitButton7);
        TheEnd7 = new Scene(paneEnd7, width, height);

//        ending2
        Button continueButton16 = new Button("Continue...");
        continueButton16.setTranslateX(-10);
        continueButton16.setTranslateY(150);
        continueButton16.setOnAction(e -> primaryStage.setScene(TheEnd9));

        Image endImage8 = new Image("https://ingridauerinternational.files.wordpress.com/2017/12/adobestock_139736787.jpg", width, height, false, false);
        ImageView imgViewEnd8 = new ImageView(endImage8);
        Group rootEnd8 = new Group(imgViewEnd8);
        Text labelEnd8 = new Text(TheEndScene.getTheEndScenePart2a());
        labelEnd8.setFont(Font.font("TimesNewRoman", 19));
        labelEnd8.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd8 = new StackPane();
        paneEnd8.getChildren().add(rootEnd8);
        paneEnd8.getChildren().add(labelEnd8);
        paneEnd8.getChildren().add(continueButton16);
        TheEnd8 = new Scene(paneEnd8, width, height);

        Button continueButton17 = new Button("Continue...");
        continueButton17.setTranslateX(-10);
        continueButton17.setTranslateY(150);
        continueButton17.setOnAction(e -> primaryStage.setScene(TheEnd10));
        ImageView imgViewEnd9 = new ImageView(endImage8);
        Group rootEnd9 = new Group(imgViewEnd9);
        Text labelEnd9 = new Text(TheEndScene.getTheEndScenePart2b());
        labelEnd9.setFont(Font.font("TimesNewRoman", 19));
        labelEnd9.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd9 = new StackPane();
        paneEnd9.getChildren().add(rootEnd9);
        paneEnd9.getChildren().add(labelEnd9);
        paneEnd9.getChildren().add(continueButton17);
        TheEnd9 = new Scene(paneEnd9, width, height);

        Button StartOverButton8 = new Button("Start Over");
        StartOverButton8.setTranslateX(-10);
        StartOverButton8.setTranslateY(200);
        StartOverButton8.setOnAction(e -> primaryStage.setScene(prologue));
        Button quitButton8 = new Button("Quit");
        quitButton8.setTranslateX(-10);
        quitButton8.setTranslateY(230);
        quitButton8.setOnAction(e -> primaryStage.close());
        continueButton17.setOnAction(e -> primaryStage.setScene(TheEnd10));
        ImageView imgViewEnd10 = new ImageView(endImage8);
        Group rootEnd10 = new Group(imgViewEnd10);
        Text labelEnd10 = new Text(TheEndScene.getTheEndScenePart2c());
        labelEnd10.setFont(Font.font("TimesNewRoman", 19));
        labelEnd10.setFill(Color.YELLOW);
        labelMarketScene3.setStroke(Color.BLACK);
        StackPane paneEnd10 = new StackPane();
        paneEnd10.getChildren().add(rootEnd10);
        paneEnd10.getChildren().add(labelEnd10);
        paneEnd10.getChildren().add(StartOverButton8);
        paneEnd10.getChildren().add(quitButton8);
        TheEnd10 = new Scene(paneEnd10, width, height);

        ////////////////////////////////////
        primaryStage.setScene(prologue);
        Scene scene = new Scene(pane1, width, height);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Bioland");
        primaryStage.show();
    }
    MediaPlayer mediaPlayer;
    MediaPlayer mediaPlayer2;
    MediaPlayer GameOver;
    
    public void music(){
        String s = "Crazy Dave's Theme Slowed Down.mp3";
        Media h = new Media(Paths.get(s).toUri().toString());
        mediaPlayer = new MediaPlayer(h);
        mediaPlayer.setOnEndOfMedia(new Runnable(){
            public void run(){
                mediaPlayer.seek(Duration.ZERO);
            }
        });
        mediaPlayer.play();    
    }
    public void musicStop(){
        mediaPlayer.stop();
    }
    public void music2(){
        String s = "Potential-Game-Over.mp3";
        Media h = new Media(Paths.get(s).toUri().toString());
        mediaPlayer2 = new MediaPlayer(h);
        mediaPlayer2.setOnEndOfMedia(new Runnable(){
            public void run(){
                mediaPlayer2.seek(Duration.ZERO);
            }
        });
        mediaPlayer2.play();
    }
     public void musicStop2(){
        mediaPlayer2.stop();
    }
     public void GameOver(){
        String s = "game_over_guitar.mp3";
        Media h = new Media(Paths.get(s).toUri().toString());
        GameOver = new MediaPlayer(h);
        GameOver.setOnEndOfMedia(new Runnable(){
            public void run(){
                GameOver.seek(Duration.ZERO);
            }
        });
        GameOver.play();
    }

    public static void main(String[] args) {

        launch(args);

    }

}
