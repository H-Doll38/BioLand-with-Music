package bioland_game2;

public class Strings {

    public static String getPrologue() {
        return "You wake up on the floor in your bedroom of your house. "
                + "\n Near the clavicle of your left shoulder, a cut the width "
                + "\n of a human palm oozes red. A small puddle of blood gathers"
                + "\n beneath your armpit. \n\n“You’re bleeding from a cut and need to treat it";

    }

    public static String getPrologue2() {
        return "(You rise from the floor)";

    }

    public static String getPrologue3() {
        return "A sideboard cabinet is pushed against the wall to your left. "
                + "\n On the other side of your bed is a nightstand, and on the "
                + "\n nightstand is a lamp. Attached to your bedroom is a bathroom.";

    }

    public static String getPrologue4() {
        return "(You walk into the bathroom and turn on the light). ";

    }

    public static String getPrologue5() {
        return "Grime covers most of the tile, sink, and bathtub."
                + "\n A mirror cabinet is above the sink."
                + "\n In the mirror you look unshaven, your face sunken-in,"
                + "\n gaunt as if you haven’t eaten in some time.";

    }

    public static String getPrologue6() {
        return "(You open the mirror cabinet and search for medical supplies."
                + "\n You find a roll of gauze, rubbing alcohol, and a bottle "
                + "\n of painkillers).";

    }

    public static String getPrologue7() {
        String a = "After taking off your shirt and setting it aside, "
                + "\n you bend over the sink and pour the rubbing alcohol "
                + "\n over your wound, grimacing. You let the alcohol settle, "
                + "\n then unroll the gauze and wrap it around your shoulder. "
                + "\n You take four painkillers). A noise comes from deeper inside "
                + "\n your house, possibly from the kitchen or living area; you "
                + "\n hear glass break, a wooden bowl hitting the floor, a stool "
                + "\n dragging against the kitchen tile.";
        return a;

    }

    public static String getPrologue8() {
        return "(You call out: Sarah? Is that you? Lily?) \n"
                + " Nobody answers, though the sounds continue.";

    }

    public static String getPrologue9() {
        return "(You exit the bathroom and search for a weapon. "
                + "\n You circle around the bed and open the drawer to the "
                + "\n nightstand, forgetting you lent LeFleur your Glock 19 last "
                + "\n month. The nightstand is empty besides a book on mechanical"
                + "\n engineering and a bundle of pencils).";

    }

    public static String getPrologue10() {
        String a = "(You kneel to check under the bed, finding a golf club. "
                + "\n You take the golf club and grip its handle, preparing "
                + "\n to go confront the potential intruder).";
        String b = "\n More crashing, rumbling around occurs outside your door";
        return a + b;

    }

    public static String getPrologue11() {

        String a = "(Taking hold of the doorknob, you swing open the door "
                + "\n and take a step back, golf club raised.)";
        String b = "\n In the light of a lamp in the living room, the walls, "
                + "\n the windows, though no human form or animal comes into sight.";
        return a + b;

    }

    public static String getPrologue12() {
        return "(As you walk down the hallway, you notice the pictures of your "
                + "\n wife, Sarah, and your daughter, Lily. The pictures are "
                + "\n turned sideways on the wall, as if someone had bumped into "
                + "\n the frames. You particularly notice a photograph that shows"
                + "\n the three of you covered in mud at a local campground, your "
                + "\n dog Oscar, a labradoodle,laying at your feet, also covered "
                + "\n in mud. LeFleur took the picture. Those were happier times).";

    }

    public static String getPrologue13() {
        String a = "(When you enter the living room, you see a grotesque figure "
                + "\n in the lamplight, kneeling over a hunk of dead flesh, the "
                + "\n meat dripping, staining the carpet red. On the floor beside "
                + "\n the piece of flesh, you can just make nout the red fabric "
                + "\n of its collar among tufts of fur, and the glint of the dog tag).";
        String b = "\n\n The figure looks up from its meal, the upper half of its "
                + "\n head torn away, its left eye dangling from its socket. It "
                + "\n staggers towards you.";
        return a + b;

    }

    public static String getPrologue14() {

        String a = "(You stand your ground, frozen in place. "
                + "\n The creature lumbers onward, already halfway to you."
                + "\n Without thinking, you crank back the golf club and bring"
                + "\n it down on the creature’s head. It falls sideways and lands"
                + "\n on its stomach, then attempts to get up. You do not give it"
                + "\n the chance. You raise the golf club again and bring it down"
                + "\n on the creature’s head, creating a crater where the back of"
                + "\n its skull once was. The figure goes still).";
        return a;

    }

    public static String getFightInLivingRoom() {
        return "(You stand your ground, frozen in place. The creature lumbers "
                + "\n onward, already halfway to you. Without thinking, you crank "
                + "\n back the golf club and bring it down on the creature’s head. "
                + "\n It falls sideways and lands on its stomach, then attempts "
                + "\n to get up. You do not give it the chance. You raise the golf "
                + "\n club again and bring it down on the creature’s head, creating "
                + "\n a crater where the back of its skull once was. The figure "
                + "\n goes still). ";
    }

    public static String getRunandHide() {
        return "(You stand your ground, frozen in place. The creature lumbers" 
                + "\n onward, already halfway to you.  Your fight of flight "
                + "\n kicks in so you decide to run and hide from the figure.  "
                + "\n As you make a break for the closet, the corpse tackles you "
                + "\n and rips and tears at your flesh.)"
                + "\n\n Game Over...";
    }
  public static String getConfuseScene() {
      return "(As the figures goes limp and bleeds profusely out of its orifices "
              + "\n from its face, you let your grip loosen on the golf club.)\n" 
              +"\n “What the hell is going on around here.”\n" 
              +"\n (You turn on the news and see an emergency broadcast alert "
              + "\n playing of the situation.  People have been having aggressive "
              + "\n reactions towards one another and becoming cannibals, "
              + "\n considering them zombie-like creatures.)\n" 
              +"\n (You turn off the tv and start to form a plan. Find supplies, "
              + "\n a safe shelter, your wife, and daughter. With that you grab "
              + "\n your coat from the hanger, a backpack, and the rest of the "
              + "\n medical supplies.)";
  }   
}
