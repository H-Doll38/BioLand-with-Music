/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bioland_game2;

import java.util.Random;

/**
 *
 * @author lork8
 */
public class RandomNumGenerator {
    public static void main(String[] args) {
        int randNum = (int) (Math.random() * 2) + 1;
        System.out.println(randNum);
    } 
//    public static void main(String[] args) {
//        
//        System.out.println(getsurvialChance(0));
//    }

//    public static String getsurvialChance(double randNum) {
//
//        return new Random().nextDouble() >= randNum ? "Dead" : "Alive";
//    }
    
public static int getsurvialChance() {
      int randNum = (int)(Math.random() * 6 + 1);
     
    
    return randNum;
};

   
}
