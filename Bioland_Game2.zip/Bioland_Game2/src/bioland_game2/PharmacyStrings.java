/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bioland_game2;

/**
 *
 * @author lork8
 */
public class PharmacyStrings {

    public static String getPharmScene() {
        return "(You slowly walk up to the building, the neon lights on the sign "
                + "\n flickers. The front is closed off by a locked gate. An "
                + "\n alleyway runs alongside the building, you decide to go "
                + "\n down it to find another way inside. In the alleyway you "
                + "\n find a rusty lead pipe. You decide to switch it out for "
                + "\n your golf club.)\n\n"
                + "“You see a closed grimy window above a closed dumpster.”";
    }

    public static String getPharmScene2() {
        return "(You climb on the dumpster and attempt to open the window)";
    }

    public static String getPharmScene3() {
        return "“With a loud smash and clatter of glass shards, the window is "
                + "\n now open.”";
    }

    public static String getPharmScene4() {
        return "(You shimmy your way in and cut your stomach on a shard of glass.)\n\n"
                + "“The room you enter appears to be a bathroom. There’s blood "
                + "\n on the tile and blood smeared on the sink. There looks to "
                + "\n be nothing of use.”";
    }

    public static String getPharmScene5() {
        return "(Your peek outside the bathroom)";
    }

    public static String getPharmClearOut() {
        return "(You decide to clear the area of any enemies. Along the way you "
                + "\n find a zombie torso munching on the dead pharmacist’s leg.  "
                + "\n While it is distracted, you hit it with pipe in the back of"
                + "\n the head, caving in its skull. The other aisles look clear, "
                + "\n so you decide to ransack the place.)";
               
    }
    public static String getPharmScene6(){
         return "(You find the following:  Med-kit, gauze, painkillers, scalpel, "
                + "\n\tpliers, and antibiotics.)";
    }
 public static String getPharmClearOutNScene7() {
     return "(You decide to clear the area of any enemies. Along the way you find "
                + "\n a zombie torso munching on the dead pharmacist’s leg.  "
                + "\n While it is distracted, you hit it with pipe in the back "
             + "\n of the head, caving in its skull. The other aisles look clear, "
             + "\n so you decide to ransack the place.)\n\n"
             + " “You hear several bangs on the closet door in the back of the "
             + "\n pharmacy, the sound of the door swinging open.  Not long "
             + "\n after three walking corpses amble towards you.” ";
             
 }
 
    public static String getPharmScene7() {
        return "“You hear several bangs on the closet door in the back of the "
                + "\n pharmacy, the sound of the door swinging open.  Not long "
                + "\n after three walking corpses amble towards you.” ";
    }

    public static String getPharmRunScene() {
        return "(You decide to run. You knock over a couple shelving units to "
                + "\n aid in your escape. You run back the way you came and lock "
                + "\n the door behind you. Loud bangs echo through the bathroom.)";
    }
    public static String getPharmRunDieScene(){
        return "(You decide to run. You knock over a couple shelving units to "
                + "\n aid in your escape, but trip along with it and spring your "
                + "\n ankle. You lay there helplessly as loud bangs open the "
                + "\n bathroom door. The undead approaches..."
                + "\n Game Over...";
    }

    public static String getPharmFightWinScene() {
        return "(You decide to fight.  The three corpses amble after you. You "
                + "\n hit the first with the lead pipe, killing the corpse, but "
                + "\n the pipe breaks on impact. The remaining two corpses come "
                + "\n at you. You lead them through an aisleway. At the end of "
                + "\n the aisleway you knock over the shelving unit, trapping the "
                + "\n two corpses.)"
                +"\n\n(You exit out the way you came, through the broken window. ";
//                + "\nThe scene ends with you running down the alleyway to the street.)";
    }

    public static String getPharmFightLoseScene() {
        return "(You decide to fight.  The three corpses amble after you. You "
                + "\n hit the first with the lead pipe, killing the corpse, but "
                + "\n the pipe breaks on impact. The remaining two corpses come "
                + "\n at you. You lead them through an aisleway. At the end of "
                + "\n the aisleway you knock over the shelving unit, trapping the "
                + "\n two corpses. You walk too close to the shelving unit, and "
                + "\n a corpse hand reaches out and grabs your ankle, dragging "
                + "\n you beneath the unit.  Blood starts to pool from underneath)"
                + "\n\n GAME OVER...";
    }
    public static String getPharmYouLiveScene() {
        return "(You exit out the way you came, through the broken window.)";
    }


}
