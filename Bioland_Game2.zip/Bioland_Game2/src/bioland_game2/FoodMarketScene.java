/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bioland_game2;

/**
 *
 * @author lork8
 */
public class FoodMarketScene {

    public static String getFoodMarketScene() {
        return "“You walk down the street, keeping to the residential bushes. "
                + "\n Eventually you come to a parking lot of a local food mart."
                + "\n Some corpses walk among the cars, but they do not notice "
                + "\n you. You sneak from car to car past the corpses and edge "
                + "\n along the building.”";
    }

    public static String getFoodMarketScene2() {
        return "“Inside the loading bay there is one truck with an empty back. "
                + "\n There doesn’t seem to be anything of use here.”";
    }

    public static String getFoodMarketScene3() {
        return "“The air is rank and the lights are off. The only light comes "
                + "\n from the sunlight outside the store, filtering in through "
                + "\n the few windows of the store. Near the checkout section, "
                + "\n you spot a group of five living people. One of them sees "
                + "\n you and points you out to the rest of the individuals. "
                + "\n They stop what they are doing and approach.”\n"
                + "\n “Who the hell are you?”";
    }

    public static String getFoodMarketChoice1() {
        return "(One of the figures slowly comes out of the shadow. He talks "
                + "\n with you further.)"
                + "\n “The man is greasy haired, rugged in his appearance.  He "
                + "\n looks sleepless and his eyes are bloodshot.  At his hip "
                + "\n dangles a sheathed kukri. The rest of the group stays back "
                + "\n in the shadows. "
                + "\n\n“Well, there’s plenty of it around here. Help yourself.”";
    }

    public static String getFoodMarketChoice2() {
        return "(A muzzle flash comes from the darkness; you fall to the ground "
                + "\n with a giant hole in your face.)"
                + "\n Game Over...";
    }public static String getFoodMarketAskQuestion() {
        return "Sure, you may ask anything.";
    }

    public static String getFoodMarketRespond() {
        return "“No. No we haven’t seen anything.”";
    }

    public static String getFoodMarketRespond2() {
        return "“It’s the fucking end of the world man, there’s no electricity.”";
    }

    public static String getFoodMarketRespond3() {
        return "“Most of the food is rotting. And those damn corpses certainly "
                + "\n don’t help.”";
    }

    public static String getFoodMarketChooseWalkAisles() {
        return "(You walk the aisles looking for quality foods.  As you peruse "
                + "\n the canned food section, you hear a surge of voices "
                + "\n amongst the group but cannot make out they say.)\n"
                + "\n (You look at the different brands of chicken noodle soup "
                + "\n when out of nowhere a gunshot and chanting ring out at the "
                + "\n end of the aisle you’re in.  A can explodes right by your "
                + "\n head. You dart in opposite direction of the gunshot while "
                + "\n popping off three rounds with the Glock. At the end of the "
                + "\n aisle, you hide behind a shelf.)";
    }
public static String getFoodMarketChooseWalkAisles2() {
        return "(You walk away towards the aisles looking for quality foods.  "
                + "\n As you peruse the canned food section, you hear a surge of "
                + "\n voices amongst the group but cannot make out they say.)\n"
                + "\n (You look at the different brands of chicken noodle soup "
                + "\n when out of nowhere a gunshot and chanting ring out at the "
                + "\n end of the aisle you’re in.  A can explodes right by your "
                + "\n head. You dart in opposite direction of the gunshot while "
                + "\n popping off three rounds with the Glock. At the end of the "
                + "\n aisle, you hide behind a shelf.)";
    }
    public static String getFoodMarketScene4() {
        return "“The fuck are you doing?!”\n"
                + "\n(You take cover in the next aisle over. You hear shouts and"
                + "\n voices coming closer. You risk a peak down the aisle and "
                + "\n see a figure on the checkout conveyor belt. It looks as if"
                + "\n the group had been dismembering the body, preparing it "
                + "\n like a meal.)"
                + "\n (You decide to flank the group, you continue along the "
                + "\n aisle to the front of the store. You take cover behind a "
                + "\n shelf at the end of the aisle. You stuff some canned goods"
                + "\n in your jacket. The corpses outside are banging on the "
                + "\n windows, making their way in.)";
              
    }
    public static String getFoodMarketScene5() {
        return "(More gunshots ring out as the group fires at the corpses."
                + "\n While they’re distracted you take cover behind the conveyor"
                + "\n belts at the front. You peak over the counter and see the"
                + "\n dead lifeless eyes of your friend Le Fleur staring back "
                + "\n at you.)";
    }
    public static String getFoodMarketGetRevengeChoice1() {
        return "(You are filled with rage and start popping round after round"
                + "\n into the distracted group. You take out two and wound the"
                + "\n leader. The other two shoot back at you so you take ncover. "
                + "\n You creep outside the front door and escape by the skin"
                + "\n of your teeth.)";
    }

    public static String getFoodMarketGetRevengeChoice2() {
        return "(You leave the store and let nature takes it sick twisted course"
                + "\n as you hear screams and more gunshots go off behind you.)";
    }

  

}
