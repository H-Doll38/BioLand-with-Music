/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bioland_game2;

/**
 *
 * @author lork8
 */
public class TheEndScene {

    public static String getTheEndScene() {
        return "“As you run along the street, a congregation of voices rises up "
                + "\n from a nearby fire station.  Some of the voices sound "
                + "\n familiar but you can’t quite place them.”\n"
                + "\n (You shoot at the corpses following you until your magazine "
                + "\n runs empty. You reload the gun and make a break for the "
                + "\n entrance of the fire station. A man holds the door open "
                + "\n for you. Once you are inside, he slams the door behind you. "
                + "\n Not long after he shuts it, you hear corpses banging on "
                + "\n the door.)";
    }

    public static String getTheEndScene2() {
        return "“Inside the fire station, there are families everywhere, lining "
                + "\n the walls and laying on the floor.  They stare at you, "
                + "\n bewildered.”\n"
                + "\n\n “Who are you?”";
    }

    public static String getTheEndScene3() {
        return "(You see a familiar figure walk out of the crowd. It is your wife "
                + "\n Sarah, she embraces you, unable to speak because she is "
                + "\n choked up.)";

    }

    public static String getTheEndScene4() {
        return "“She’s at the lighthouse, but…”"
                + "\n\n (The corpses break in through the windows, through the "
                + "\n front door, pouring in the fire station. They tackle people "
                + "\n to the ground, devouring their flesh. Some people fight "
                + "\n back with fire axes and table legs but it is not enough. "
                + "\n You and a group of people make a break for the back door.)";

    }

    public static String getTheEndScene5() {
        return "“Once you go out the back door, the sky is pitch black and the "
                + "\n air is cold. You see thick woods ahead, corpses stumble "
                + "\n from all directions.  You must dodge and weave.  One of "
                + "\n the plump individuals trips and gets turned into a human "
                + "\n happy meal, aiding in your escape.”";

    }

    public static String getTheEndScene6() {
        return "“You see an opening through the thicket and enter there.  "
                + "\n The branches whip and tear at your skin as you bust on "
                + "\n through. From there, you traverse the stand of cottonwoods "
                + "\n until they open into a clearing. To your left, you see a "
                + "\n boatyard filled with sailboats, rowboats, and dinghies.  "
                + "\n On your right you see the lighthouse. The group, including "
                + "\n your wife, runs towards the boatyard. She turns around and "
                + "\n calls to you.”\n"
                + "\n “What are you doing Hank?”";

    }

    public static String getTheEndScenePart1() {
        return "(You nod at your wife and run with her and the group to the "
                + "\n boatyard.)"
                + "\n\n (Corpses come out from between the sailboats and pounce on "
                + "\n the unsuspecting people, ripping their throats out. While "
                + "\n others get cornered and maliciously gnawed on, you make a "
                + "\n path with the remaining bullets in your gun. You reload "
                + "\n your final magazine.)\n"
                + "\n(Your wife slips the dock lines from their cleats, releasing "
                + "\n a small rowboat. You hop in and fit the oars in the oarlocks "
                + "\n and row out of the harbor, to the river. At the middle of "
                + "\n the river, you look back at the shore to the lighthouse.  "
                + "\n Your wife sees you looking. She looks away…)"
                + "\n\nThe End."; //*black screen* "

    }

    public static String getTheEndScenePart2a() {
        return "(You shake your head and dart towards the lighthouse.)\n"
                + "\n (The sand from the beach slows your running down. Corpses "
                + "\n along the beach try stumbling toward you but their progress "
                + "\n is also slowed by the sand.  The corpses wear beach clothing "
                + "\n such as bikinis, swim shorts, and Speedos.)\n"
                + "\n (Outside the lighthouse, you try the door and find it strangely "
                + "\n unlocked. You aim your gun through the crack of the door and "
                + "\n slowly open it.)";

    }

    public static String getTheEndScenePart2b() {
        return "“After entering the lighthouse, you shut the door behind you and "
                + "\n lock it.  The inside of the lighthouse is dim. In one corner "
                + "\n of the room, there is a tacklebox and a fishing pole. In another "
                + "\n corner, tied to a support beam by rope, is your daughter Lily. "
                + "\n She snarls and snaps at you with her teeth.”\n"
                + "\n Hank: “Oh god…Lily”\n"
                + "\n “Outside, corpses bang on the door.  You ignore them and step "
                + "\n towards your daughter.”";

    }

    public static String getTheEndScenePart2c() {
        return "(You raise your gun to her forehead.)\n"
                + "\n Hank- “I am so sorry Lily pad.”\n"
                + "“\n You turn your head and slowly squeeze the trigger. "
                + "\n Tears roll down your cheeks.  You find a tarp to cover her"
                + "\n body with before making your way up the spiral staircase.”\n"
                + "\n “At the top of the lighthouse, you feel the wind blowing "
                + "\n off the river on your face. You lean on the railing and "
                + "\n look out over the river. You hear corpses start to break "
                + "\n in downstairs. You watch as a single rowboat rows away "
                + "\n into open water. You swear you see the person rowing look "
                + "\n back at you.”\n"
                + "\n"
                + "Game Over...  ";

    }

}
