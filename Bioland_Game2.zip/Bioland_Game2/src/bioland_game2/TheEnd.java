/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bioland_game2;

/**
 *
 * @author lork8
 */
public class TheEnd {

    public static String getTheEndScene() {
        return "“As you run along the street, a congregation of voices rises up "
                + "\nfrom a nearby fire station.  Some of the voices sound familiar "
                + "\nbut you can’t quite place them.”\n"
                + "\n(You shoot at the corpses following you until your magazine runs "
                + "\nempty. You reload the gun and make a break for the entrance of "
                + "\nthe fire station. A man holds the door open for you. Once you "
                + "\nare inside, he slams the door behind you. Not long after he shuts it, "
                + "\nyou hear corpses banging on the door.)";
    }

    public static String getTheEndScene2() {
        return "“Inside the fire station, there are families everywhere, lining the "
                + "\nwalls and laying on the floor.  They stare at you, bewildered.”\n"
                + "\nA random individual: “Who are you?”";
    }

    public static String getTheEndScene3() {
        return "Same thing for both: (you see a familiar figure walk out of the crowd. "
                + "\nIt is your wife Sarah, she embraces you, unable to speak because "
                + "\nshe is choked up.)";

    }

    public static String getTheEndScene4() {
        return "";

    }

    public static String getTheEndScene5() {
        return "";

    }

    public static String getTheEndScene6() {
        return "";

    }

    public static String getTheEndScene7() {
        return "";

    }

    public static String getTheEndScene8() {
        return "";

    }

    public static String getTheEndScene9() {
        return "";

    }

    public static String getTheEndScene10() {
        return "";

    }

    public static String getTheEndScene11() {
        return "";

    }

    public static String getTheEndScene12() {
        return "";

    }

    public static String getTheEndScene13() {
        return "";

    }

    public static String getTheEndScene14() {
        return "";

    }

    public static String getTheEndScene15() {
        return "";

    }

    public static String getTheEndScene16() {
        return "";

    }

    public static String getTheEndScene17() {
        return "";

    }

    public static String getTheEndScene18() {
        return "";

    }

    public static String getTheEndScene19() {
        return "";
    }
}
